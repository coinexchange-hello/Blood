// $(window).on('load', function(){

  
// })


jQuery( document ).ready(function($){
	setTimeout(function(){
		$('.loaderContainer').hide();
	}, 500);
	var current = 1;
		$('.progress-bar').addClass('step-' + current);
    $('.nextBtn:not(.lastBtn').on('click', function (e) {
    	e.preventDefault();
		$(this).closest('.step').hide().next('.step').fadeIn();
		
		//function to increase by buttonclick

		  $('.progress-bar').removeClass('step-' + current)
		  current = current + 1
		  $('.progress-bar').addClass('step-' + current)

    })
   
    $('.lastBtn').on('click', function (e) {
    	e.preventDefault(e);

        window.location.href = 'https://btthunder.com/path/out.php';
    });
   
});

